package com.example.eventbooking.notification;

public class NotificationViewModel {
}
