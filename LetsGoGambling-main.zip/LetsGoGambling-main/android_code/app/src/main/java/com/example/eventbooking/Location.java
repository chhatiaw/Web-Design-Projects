package com.example.eventbooking;


/**
 * Class is temporaraiailly disabled as passing and getting this data from firebase made loading
 * and uploading fail consistently due to passing a value into a class
 */
public class Location {
    private String address;
    private int latitude;
    private int longitude;




}
